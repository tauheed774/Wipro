# Wipro
Wipro training program.
Shipra Pal.
This is my Profile Page.
